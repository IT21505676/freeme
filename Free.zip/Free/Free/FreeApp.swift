//
//  FreeApp.swift
//  Free
//
//  Created by vikasitha herath on 2023-07-14.
//

import SwiftUI

@main
struct FreeApp: App {
    var body: some Scene {
        WindowGroup {
            HomePageView()
        }
    }
}
