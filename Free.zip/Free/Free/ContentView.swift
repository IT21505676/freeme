//
//  ContentView.swift
//  Free
//
//  Created by vikasitha herath on 2023-07-14.
//

import SwiftUI


struct HomePageView: View {
    var body: some View {
        NavigationView {
            VStack(alignment: .leading, spacing: 60.0) {
                Text("   Unit Converter")
                    .font(.largeTitle)
                    .fontWeight(.bold)
                    .foregroundColor(.black)
                
                NavigationLink(destination: LengthView()) {
                    Label("Units of Length (Distance)", systemImage: "ruler")
                        .foregroundColor(.blue)
                        .padding()
                        .background(Color.yellow) // Updated background color
                        .cornerRadius(10) // Added corner radius
                }
                
                NavigationLink(destination: MassView()) {
                    Label("Units of Mass (Weight)       ", systemImage: "scalemass")
                        .foregroundColor(.blue)
                        .padding()
                        .background(Color.green) // Updated background color
                        .cornerRadius(10) // Added corner radius
                }
                
                NavigationLink(destination: CapacityView()) {
                    Label("Units of Capacity (Volume)", systemImage: "cube.box")
                        .foregroundColor(.blue)
                        .padding()
                        .background(Color.purple) // Updated background color
                        .cornerRadius(10) // Added corner radius
                }
                
                NavigationLink(destination: TemperatureView()) {
                    Label("Temperature                              ", systemImage: "thermometer")
                        .foregroundColor(.blue)
                        .padding()
                        .background(Color.orange) // Updated background color
                        .cornerRadius(10) // Added corner radius
                }
                
                NavigationLink(destination: AreaCalculationView()) {
                    Label("Area Calculation                    ", systemImage: "square.grid.2x2")
                        .foregroundColor(.blue)
                        .padding()
                        .background(Color.red) // Updated background color
                        .cornerRadius(10) // Added corner radius
                }
            }
            Image(systemName: "house.fill")
        }

    }
}

struct LengthView: View {
    // Input variables
    @State private var inputValue = ""
    @State private var selectedInputUnitIndex = 0
    @State private var selectedOutputUnitIndex = 1
    
    // Output variable
    private let units = ["km", "hm", "dam", "m", "dm", "cm", "mm"]
    
    private var convertedValue: Double {
        let input = Double(inputValue) ?? 0
        
        let inputUnit = units[selectedInputUnitIndex]
        let outputUnit = units[selectedOutputUnitIndex]
        
        switch (inputUnit, outputUnit) {
        case ("km", "hm"):
            return input * 10 // 1 km = 10 hm
        case ("km", "dam"):
            return input * 100 // 1 km = 100 dam
        case ("km", "m"):
            return input * 1000 // 1 km = 1000 m
        case ("km", "dm"):
            return input * 10000 // 1 km = 10000 dm
        case ("km", "cm"):
            return input * 100000 // 1 km = 100000 cm
        case ("km", "mm"):
            return input * 1000000 // 1 km = 1000000 mm
        case ("m", "cm"):
            return input * 100 // 1 m = 100 cm
        case ("m", "mm"):
            return input * 1000 // 1 m = 1000 mm
        case ("cm", "mm"):
            return input * 10 // 1 cm = 10 mm
        default:
            return 0
        }
    }
    
    var body: some View {
        Form {
            Section(header: Text("Input")) {
                TextField("Enter value", text: $inputValue)
                    .keyboardType(.decimalPad)
                
                Picker("Unit", selection: $selectedInputUnitIndex) {
                    ForEach(0..<units.count) { index in
                        Text(self.units[index])
                    }
                }
                .pickerStyle(SegmentedPickerStyle())
            }
            
            Section(header: Text("Output")) {
                Text("Converted Value: \(convertedValue, specifier: "%.2f")")
                    .font(.headline)
            }
            
            Section(header: Text("Convert to")) {
                Picker("Unit", selection: $selectedOutputUnitIndex) {
                    ForEach(0..<units.count) { index in
                        Text(self.units[index])
                    }
                }
                .pickerStyle(SegmentedPickerStyle())
            }
        }
        .navigationTitle("Units of Length")
        
    }
    
}

struct MassView: View {
    // Input variables
    @State private var inputValue = ""
    @State private var selectedInputUnitIndex = 0
    @State private var selectedOutputUnitIndex = 1
    
    // Output variable
    private let units = ["t", "kg", "hg", "dag", "g", "dg", "cg", "mg"]
    
    private var convertedValue: Double {
        let input = Double(inputValue) ?? 0
        
        let inputUnit = units[selectedInputUnitIndex]
        let outputUnit = units[selectedOutputUnitIndex]
        
        switch (inputUnit, outputUnit) {
        case ("t", "kg"):
            return input * 1000 // 1 t = 1000 kg
        case ("t", "g"):
            return input * 1000000 // 1 t = 1000000 g
        case ("kg", "g"):
            return input * 1000 // 1 kg = 1000 g
        case ("hg", "g"):
            return input * 100 // 1 hg = 100 g
        case ("dag", "g"):
            return input * 10 // 1 dag = 10 g
        case ("dg", "g"):
            return input * 0.1 // 1 dg = 0.1 g
        case ("cg", "g"):
            return input * 0.01 // 1 cg = 0.01 g
        case ("mg", "g"):
            return input * 0.001 // 1 mg = 0.001 g
        default:
            return 0
        }
    }
    
    var body: some View {
        Form {
            Section(header: Text("Input")) {
                TextField("Enter value", text: $inputValue)
                    .keyboardType(.decimalPad)
                
                Picker("Unit", selection: $selectedInputUnitIndex) {
                    ForEach(0..<units.count) { index in
                        Text(self.units[index])
                    }
                }
                .pickerStyle(SegmentedPickerStyle())
            }
            
            Section(header: Text("Output")) {
                Text("Converted Value: \(convertedValue, specifier: "%.2f")")
                    .font(.headline)
            }
            
            Section(header: Text("Convert to")) {
                Picker("Unit", selection: $selectedOutputUnitIndex) {
                    ForEach(0..<units.count) { index in
                        Text(self.units[index])
                    }
                }
                .pickerStyle(SegmentedPickerStyle())
            }
        }
        .navigationTitle("Units of Mass")
    }
}

struct CapacityView: View {
    // Input variables
    @State private var inputValue = ""
    @State private var selectedInputUnitIndex = 0
    @State private var selectedOutputUnitIndex = 1
    
    // Output variable
    private let units = ["kL", "hL", "daL", "L", "dL", "cL", "mL"]
    
    private var convertedValue: Double {
        let input = Double(inputValue) ?? 0
        
        let inputUnit = units[selectedInputUnitIndex]
        let outputUnit = units[selectedOutputUnitIndex]
        
        switch (inputUnit, outputUnit) {
        case ("kL", "hL"):
            return input * 10 // 1 kL = 10 hL
        case ("kL", "daL"):
            return input * 100 // 1 kL = 100 daL
        case ("kL", "L"):
            return input * 1000 // 1 kL = 1000 L
        case ("kL", "dL"):
            return input * 10000 // 1 kL = 10000 dL
        case ("kL", "cL"):
            return input * 100000 // 1 kL = 100000 cL
        case ("kL", "mL"):
            return input * 1000000 // 1 kL = 1000000 mL
        case ("L", "mL"):
            return input * 1000 // 1 L = 1000 mL
        default:
            return 0
        }
    }
    
    var body: some View {
        Form {
            Section(header: Text("Input")) {
                TextField("Enter value", text: $inputValue)
                    .keyboardType(.decimalPad)
                
                Picker("Unit", selection: $selectedInputUnitIndex) {
                    ForEach(0..<units.count) { index in
                        Text(self.units[index])
                    }
                }
                .pickerStyle(SegmentedPickerStyle())
            }
            
            Section(header: Text("Output")) {
                Text("Converted Value: \(convertedValue, specifier: "%.2f")")
                    .font(.headline)
            }
            
            Section(header: Text("Convert to")) {
                Picker("Unit", selection: $selectedOutputUnitIndex) {
                    ForEach(0..<units.count) { index in
                        Text(self.units[index])
                    }
                }
                .pickerStyle(SegmentedPickerStyle())
            }
        }
        .navigationTitle("Units of Capacity")
    }
}

struct TemperatureView: View {
    // Input variables
    @State private var inputValue = ""
    @State private var selectedInputUnitIndex = 0
    @State private var selectedOutputUnitIndex = 1
    
    // Output variable
    private let units = ["°C", "°F", "K"]
    
    private var convertedValue: Double {
        let input = Double(inputValue) ?? 0
        
        let inputUnit = units[selectedInputUnitIndex]
        let outputUnit = units[selectedOutputUnitIndex]
        
        switch (inputUnit, outputUnit) {
        case ("°C", "°F"):
            return input * 9/5 + 32 // Celsius to Fahrenheit conversion formula
        case ("°C", "K"):
            return input + 273.15 // Celsius to Kelvin conversion formula
        case ("°F", "°C"):
            return (input - 32) * 5/9 // Fahrenheit to Celsius conversion formula
        case ("°F", "K"):
            return (input - 32) * 5/9 + 273.15 // Fahrenheit to Kelvin conversion formula
        case ("K", "°C"):
            return input - 273.15 // Kelvin to Celsius conversion formula
        case ("K", "°F"):
            return (input - 273.15) * 9/5 + 32 // Kelvin to Fahrenheit conversion formula
        default:
            return 0
        }
    }
    
    var body: some View {
        Form {
            Section(header: Text("Input")) {
                TextField("Enter value", text: $inputValue)
                    .keyboardType(.decimalPad)
                
                Picker("Unit", selection: $selectedInputUnitIndex) {
                    ForEach(0..<units.count) { index in
                        Text(self.units[index])
                    }
                }
                .pickerStyle(SegmentedPickerStyle())
            }
            
            Section(header: Text("Output")) {
                Text("Converted Value: \(convertedValue, specifier: "%.2f")")
                    .font(.headline)
            }
            
            Section(header: Text("Convert to")) {
                Picker("Unit", selection: $selectedOutputUnitIndex) {
                    ForEach(0..<units.count) { index in
                        Text(self.units[index])
                    }
                }
                .pickerStyle(SegmentedPickerStyle())
            }
        }
        .navigationTitle("Temperature")
    }
}

struct AreaCalculationView: View {
    // Shape selection
    @State private var selectedShapeIndex = 0
    private let shapes = ["Square", "Circle", "Triangle"]
    
    // Input variables
    @State private var inputValue = ""
    
    // Output variable
    @State private var area: Double = 0.0
    
    private var selectedShapeIcon: String {
        switch shapes[selectedShapeIndex] {
        case "Square":
            return "square"
        case "Circle":
            return "circle"
        case "Triangle":
            return "triangle"
        default:
            return ""
        }
    }
    
    private func calculateArea() {
        let input = Double(inputValue) ?? 0
        
        switch shapes[selectedShapeIndex] {
        case "Square":
            area = input * input
        case "Circle":
            area = Double.pi * input * input
        case "Triangle":
            area = (input * input) / 2
        default:
            area = 0.0
        }
    }
    
    var body: some View {
        Form {
            Section(header: Text("Select Shape")) {
                Picker("Shape", selection: $selectedShapeIndex) {
                    ForEach(0..<shapes.count) { index in
                        Text(self.shapes[index])
                    }
                }
                .pickerStyle(SegmentedPickerStyle())
                
                Image(systemName: selectedShapeIcon)
                    .resizable()
                    .aspectRatio(contentMode: .fit)
                    .frame(width: 100, height: 100)
            }
            
            Section(header: Text("Input")) {
                TextField("Enter value", text: $inputValue)
                    .keyboardType(.decimalPad)
            }
            
            Section(header: Text("Output")) {
                Text("Area: \(area, specifier: "%.2f")")
                    .font(.headline)
            }
            
            Section {
                Button(action: {
                    calculateArea()
                }) {
                    Text("Calculate")
                        .foregroundColor(.white)
                        .padding()
                        .frame(maxWidth: .infinity)
                        .background(Color.blue)
                        .cornerRadius(10)
                }
            }
        }
        .navigationTitle("Area Calculation")
    }
}

struct ReportView: View {
    @State private var calculationHistory: [String] = []
    
    var body: some View {
        VStack {
            Text("Report")
                .font(.largeTitle)
                .fontWeight(.bold)
            
            if calculationHistory.isEmpty {
                Text("No calculations yet")
            } else {
                ScrollView {
                    VStack(alignment: .leading, spacing: 10) {
                        ForEach(calculationHistory, id: \.self) { calculation in
                            Text(calculation)
                        }
                    }
                }
            }
        }
        .padding()
        .navigationTitle("Report")
        .onAppear {
            calculationHistory = UserDefaults.standard.stringArray(forKey: "CalculationHistory") ?? []
        }
    }
}

struct UnitConverterApp: App {
    var body: some Scene {
        WindowGroup {
            HomePageView()
                .onAppear {
                    UserDefaults.standard.set([], forKey: "CalculationHistory")
                }
        }
    }
}

struct UnitConverterApp_Previews: PreviewProvider {
    static var previews: some View {
        HomePageView()
    }
}
